# better_poster_latex
The Latex version of Mike Morrison's "better poster" template.
Only portrait version for now.

Explanation here: https://www.youtube.com/watch?v=1RwJbhkCA58&t=1s

Overleaf template: https://www.overleaf.com/latex/templates/better-poster-for-scientific-presentation/xpcssnwsgwqp

Original powerpoint by Mike Morrison here https://osf.io/vxqr6/
